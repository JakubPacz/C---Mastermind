#pragma once

void wyswietl_zasady_gry();
void wyczyszczenie_konsoli();
void mastermind();