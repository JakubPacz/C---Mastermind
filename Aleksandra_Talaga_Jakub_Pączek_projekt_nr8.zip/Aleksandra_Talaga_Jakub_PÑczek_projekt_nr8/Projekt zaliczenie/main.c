// Projekt nr. 8 Gra Master Mind
// Autorzy: Aleksandra Talaga, Jakub P�czek

#include"funkcje.h"

int main() {
	wyswietl_zasady_gry();
	wyczyszczenie_konsoli();
	mastermind();
	return 0;
}